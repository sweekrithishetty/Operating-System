Assignment done by following team members:
1)Sweekrithi Shetty
2)Mukta Parab

Implemented the following functionality:-
1)Execute command with multiple arguments
For eg: 
      sh550>echo The sky is

2)Execute command in either foreground and background
For eg:
      sh550>sleep 50 &
      sh550>sleep 10 

3)Maintain multiple process running in background mode simultaneously
For eg:
      sh550>sleep 50 &
      sh550>sleep 10 &
	  sh550>ls &
4)List all currently running background 
For eg:
      sh550>listjobs
